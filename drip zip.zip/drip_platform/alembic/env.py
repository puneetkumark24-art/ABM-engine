import os, sys
from pathlib import Path
from logging.config import fileConfig
from sqlalchemy import engine_from_config, pool
from alembic import context

sys.path.insert(0, str(Path(__file__).parent.parent))
from database import Base
import models  # noqa: F401  -- registers all models on Base.metadata

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Prefer DATABASE_URL env var (real Postgres on Puneet's machine) over alembic.ini
db_url = os.environ.get("DATABASE_URL")
if db_url:
    # ConfigParser (which backs alembic's Config) treats "%" as the start of
    # an interpolation token, e.g. "%40" from a URL-encoded password looks
    # like an invalid %-substitution to it. Escape "%" -> "%%" so it's stored
    # literally; get_main_option()/get_section() un-escape it back to "%" on
    # read, so the URL SQLAlchemy actually sees is unchanged.
    config.set_main_option("sqlalchemy.url", db_url.replace("%", "%%"))

target_metadata = Base.metadata


def run_migrations_offline():
    url = config.get_main_option("sqlalchemy.url")
    context.configure(url=url, target_metadata=target_metadata, literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    connectable = engine_from_config(config.get_section(config.config_ini_section),
                                      prefix="sqlalchemy.", poolclass=pool.NullPool)
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
